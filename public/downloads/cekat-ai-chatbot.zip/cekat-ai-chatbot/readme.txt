=== Cekat AI Chatbot ===
Contributors: cekatbizid
Tags: chatbot, ai, customer service, live chat, support
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.7.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-Powered Customer Service Chatbot untuk WordPress. Integrasikan chatbot cerdas ke website Anda dalam hitungan menit.

== Description ==

Cekat AI Chatbot adalah plugin WordPress yang memungkinkan Anda menambahkan chatbot bertenaga AI ke website Anda. Chatbot ini dapat:

* Menjawab pertanyaan pelanggan secara otomatis 24/7
* Belajar dari knowledge base yang Anda definisikan
* Didukung teknologi AI generatif dan RAG (Retrieval-Augmented Generation)
* Mengumpulkan leads dari visitor website
* Integrasi WooCommerce: katalog produk (harga, stok, deskripsi) tersinkron otomatis ke knowledge base sehingga chatbot bisa menjawab pertanyaan produk dan stok

**Fitur Utama:**

* ✅ Setup mudah - hanya perlu Widget ID
* ✅ Kustomisasi tampilan widget
* ✅ Exclude halaman tertentu
* ✅ Responsive di semua device
* ✅ Dashboard untuk training AI

**Cara Kerja:**

1. Daftar akun di [cekat.biz.id](https://cekat.biz.id)
2. Buat chatbot dan isi knowledge base
3. Copy Widget ID dari dashboard
4. Paste di plugin ini
5. Selesai! Chatbot aktif di website Anda

== Installation ==

1. Upload folder `cekat-ai-chatbot` ke direktori `/wp-content/plugins/`
2. Aktivasi plugin melalui menu 'Plugins' di WordPress
3. Buka menu 'Cekat AI' di sidebar admin
4. Masukkan Widget ID dari dashboard cekat.biz.id
5. Klik 'Test Connection' untuk verifikasi
6. Save Settings

== Frequently Asked Questions ==

= Apakah saya perlu akun Cekat.biz.id? =
Ya, Anda perlu mendaftar di cekat.biz.id untuk mendapatkan Widget ID dan mengatur chatbot.

= Apakah plugin ini gratis? =
Plugin WordPress ini gratis. Layanan Cekat.biz.id memiliki tier gratis dengan batasan tertentu dan tier berbayar untuk fitur lebih lengkap.

= Bagaimana cara melatih chatbot? =
Login ke dashboard cekat.biz.id, lalu isi Knowledge Base dengan informasi tentang bisnis Anda.

= Apakah bisa dikustomisasi? =
Ya, Anda dapat mengubah warna, posisi, greeting message, dan lainnya melalui dashboard Cekat.

== Screenshots ==

1. Halaman pengaturan plugin
2. Widget chatbot di website
3. Dashboard Cekat.biz.id

== Changelog ==

= 1.7.0 =
* Dukungan pengaturan baru dari dashboard Cekat: perilaku buka widget (muncul otomatis dengan jeda detik yang bisa diatur, atau hanya saat diklik) dan gaya tombol launcher (ikon saja atau ikon + teks)

= 1.6.0 =
* Sinkronisasi konten situs: Halaman, Artikel, dan info situs (nama, deskripsi, alamat toko WooCommerce) kini bisa disinkronkan ke knowledge base chatbot, sehingga chatbot dapat menjawab pertanyaan umum tentang website (tentang kami, FAQ, kebijakan), bukan hanya produk

= 1.5.0 =
* Auto-update: plugin kini memeriksa versi terbaru langsung dari GitHub dan dapat diperbarui dari wp-admin seperti plugin wordpress.org - tanpa unduh/unggah ZIP manual lagi

= 1.4.0 =
* Saklar master integrasi WooCommerce di pengaturan plugin: satu tombol untuk mematikan seluruh integrasi (sinkron katalog produk + fitur pesanan di chat: cek status dan buat pesanan) bagi situs yang tidak memakainya

= 1.3.0 =
* Aksi webhook create_order kini membuat pesanan WooCommerce sungguhan dari percakapan chatbot (produk divalidasi + stok dicek lebih dulu) dan mengembalikan tautan pembayaran checkout toko untuk pembeli

= 1.2.0 =
* Aksi webhook check_status: chatbot dapat mengecek status pesanan WooCommerce secara real-time dari percakapan, dengan verifikasi kepemilikan (email/no. HP checkout) dan dukungan nomor resi

= 1.1.0 =
* Integrasi WooCommerce: sinkronisasi katalog produk (nama, harga, stok, kategori, deskripsi, tautan) ke knowledge base chatbot secara otomatis saat produk berubah, plus sinkronisasi penuh manual dari halaman pengaturan
* Pengaturan API Key untuk integrasi server-to-server

= 1.0.0 =
* Initial release
* Widget embed functionality
* Settings page with connection test
* Exclude pages feature
* Position selection

== Upgrade Notice ==

= 1.0.0 =
Initial release of Cekat AI Chatbot plugin.
